package cl.evaluacion2.Usuario_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
