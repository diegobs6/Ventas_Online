package cl.evaluacion2.Usuario_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuarioMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuarioMicroServicioApplication.class, args);
	}

}
