package cl.evaluacion2.Usuario_microServicio.Controller;

import cl.evaluacion2.Usuario_microServicio.Dto.UsuarioRequest;
import cl.evaluacion2.Usuario_microServicio.Dto.UsuarioResponse;
import cl.evaluacion2.Usuario_microServicio.Dto.UsuarioUpdateRequest;
import cl.evaluacion2.Usuario_microServicio.Model.Usuario;
import cl.evaluacion2.Usuario_microServicio.Service.UsuarioService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/usuarios")
@Slf4j
public class UsuarioController {

    @Autowired
    UsuarioService usuarioService;

    //LISTAR TODOS LOS USUARIOS
    @GetMapping()
    public List<Usuario> listarUsuarios() {
        log.info("GET /api/usuarios/listarUsuarios");
        return usuarioService.buscarUsuarios();
    }
    //BUSCAR USUARIO POR ID
    @GetMapping("/{id}")
    public UsuarioResponse buscarUsuarioPorId(@PathVariable Long id) {
        log.info("GET /api/usuarios/buscarUsuarioPorId/{}", id);
        return usuarioService.buscarPorId(id);
    }
    //BUSCAR USUARIO POR RUN
    @GetMapping("/run/{run}")
    public UsuarioResponse buscarUsuarioPorRun(@PathVariable String run) {
        log.info("GET /api/usuarios/buscarUsuarioPorRun/{}", run);
        return usuarioService.buscarPorRun(run);
    }
    //CREAR NUEVO USUARIO
    @PostMapping()
    public ResponseEntity<UsuarioResponse> crearUsuario(@Valid @RequestBody UsuarioRequest request) {
        log.info("POST /v1/usuarios");
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.crearUsuario(request));
    }
    //ACTUALIZAR USUARIO
    @PutMapping("/{id}")
    public ResponseEntity<UsuarioResponse> actualizarUsuario(@PathVariable Long id, @Valid @RequestBody UsuarioUpdateRequest request) {
        log.info("PUT /api/usuarios/actualizarUsuario/{}", id);
        return ResponseEntity.ok().body(usuarioService.actualizarUsuario(id, request));
    }

    //ELIMINAR USUARIO
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Long id) {
        log.info("DELETE /v1/usuarios/{}", id);
        usuarioService.eliminarUsuario(id);
        return ResponseEntity.noContent().build();
    }

}
