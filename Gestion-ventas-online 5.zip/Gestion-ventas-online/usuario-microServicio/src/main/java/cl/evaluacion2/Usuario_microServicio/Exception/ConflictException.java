package cl.evaluacion2.Usuario_microServicio.Exception;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}
