package cl.evaluacion2.Usuario_microServicio.Mapper;

import cl.evaluacion2.Usuario_microServicio.Dto.UsuarioRequest;
import cl.evaluacion2.Usuario_microServicio.Dto.UsuarioResponse;
import cl.evaluacion2.Usuario_microServicio.Model.Usuario;
import org.springframework.stereotype.Component;

@Component
public class UsuarioMapper {

    public Usuario fromRequest(UsuarioRequest request){
        return Usuario.builder()
                .run(request.getRun())
                .nombres(request.getNombres())
                .apellidos(request.getApellidos())
                .fechaNac(request.getFechaNac())
                .correo(request.getCorreo())
                .direccion(request.getDireccion())
                .build();
    }

    public UsuarioResponse toResponse(Usuario usuario) {
        return UsuarioResponse.builder()
                .id(usuario.getId())
                .run(usuario.getRun())
                .nombres(usuario.getNombres())
                .apellidos(usuario.getApellidos())
                .fechaNac(usuario.getFechaNac())
                .correo(usuario.getCorreo())
                .direccion(usuario.getDireccion())
                .build();
    }

}
