package cl.evaluacion2.Usuario_microServicio.Repository;

import cl.evaluacion2.Usuario_microServicio.Model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    boolean existsByRun(String run);

    Optional<Usuario> findByRun(String run);
}
