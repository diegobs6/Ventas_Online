package cl.evaluacion2.Envio_MicroServicio.Exception;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}
