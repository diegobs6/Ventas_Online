package cl.evaluacion2.Envio_MicroServicio.Exception;

public class ForbiddenException extends RuntimeException {
    public ForbiddenException(String message) {
        super(message);
    }
}
