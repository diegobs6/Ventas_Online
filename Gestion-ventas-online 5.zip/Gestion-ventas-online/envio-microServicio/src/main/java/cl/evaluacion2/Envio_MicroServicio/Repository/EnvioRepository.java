package cl.evaluacion2.Envio_MicroServicio.Repository;

import cl.evaluacion2.Envio_MicroServicio.Model.Envio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EnvioRepository extends JpaRepository<Envio, Long> {

    Optional<Envio> findByNumeroSeguimiento(String numeroSeguimiento);
    List<Envio> findAllByUsuarioId(Long usuarioId);
}
