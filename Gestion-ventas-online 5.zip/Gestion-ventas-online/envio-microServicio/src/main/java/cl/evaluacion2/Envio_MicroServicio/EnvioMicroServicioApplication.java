package cl.evaluacion2.Envio_MicroServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnvioMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnvioMicroServicioApplication.class, args);
	}

}
