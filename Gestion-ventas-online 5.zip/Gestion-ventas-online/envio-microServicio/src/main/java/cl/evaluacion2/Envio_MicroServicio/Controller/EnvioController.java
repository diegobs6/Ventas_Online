package cl.evaluacion2.Envio_MicroServicio.Controller;

import cl.evaluacion2.Envio_MicroServicio.Dto.EnvioRequest;
import cl.evaluacion2.Envio_MicroServicio.Dto.EnvioResponse;
import cl.evaluacion2.Envio_MicroServicio.Service.EnvioService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/envios")
@Slf4j
public class EnvioController {

    @Autowired
    private EnvioService envioService;

    @GetMapping("/usuario/{usuarioId}")
    public List<EnvioResponse> obtenerEnviosPorUsuarioId(@PathVariable Long usuarioId) {
        log.info("GET /v1/envios/usuario/{}", usuarioId);
        return envioService.obtenerEnvioPorUsuarioId(usuarioId);
    }

    @GetMapping
    public ResponseEntity<List<EnvioResponse>> obtenerEnvios() {
        log.info("GET /v1/envios");
        List<EnvioResponse> envios = envioService.listarTodos();
        return ResponseEntity.ok(envios);
    }

    @GetMapping("/seguimiento/{numeroSeguimiento}")
    public ResponseEntity<EnvioResponse> obtenerEnvioPorNumeroSeguimiento(@PathVariable String numeroSeguimiento) {
        log.info("GET /v1/envios/seguimiento/{}", numeroSeguimiento);
        EnvioResponse envios = envioService.obtenerEnvioPorNumeroSeguimiento(numeroSeguimiento);
        return ResponseEntity.ok(envios);
    }

    @PostMapping
    public ResponseEntity<EnvioResponse> crearEnvio(@Valid @RequestBody EnvioRequest envioRequest) {
        log.info("POST /v1/envios");
        EnvioResponse envioResponse = envioService.crearEnvio(envioRequest);
        return new ResponseEntity<>(envioResponse, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EnvioResponse> actualizarEnvio(
            @PathVariable Long id,
            @Valid @RequestBody EnvioRequest envioRequest) {
        log.info("PUT /v1/envios/{}", id);
        EnvioResponse envioResponse = envioService.actualizarEnvio(id, envioRequest);
        return ResponseEntity.ok(envioResponse);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEnvio(@PathVariable Long id) {
        log.info("DELETE /v1/envios/{}", id);
        envioService.eliminarEnvio(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
