package cl.evaluacion2.Envio_MicroServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
