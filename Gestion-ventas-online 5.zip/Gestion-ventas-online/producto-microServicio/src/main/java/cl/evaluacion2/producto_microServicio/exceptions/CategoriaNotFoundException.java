package cl.evaluacion2.producto_microServicio.exceptions;

public class CategoriaNotFoundException extends RuntimeException {

    public CategoriaNotFoundException(Long id) {
        super("Categoría no encontrada con ID: " + id);
    }

    public CategoriaNotFoundException(String mensaje) {
        super(mensaje);
    }
}
