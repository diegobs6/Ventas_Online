package cl.evaluacion2.producto_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductoMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductoMicroServicioApplication.class, args);
	}

}
