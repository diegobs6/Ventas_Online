package cl.evaluacion2.producto_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
