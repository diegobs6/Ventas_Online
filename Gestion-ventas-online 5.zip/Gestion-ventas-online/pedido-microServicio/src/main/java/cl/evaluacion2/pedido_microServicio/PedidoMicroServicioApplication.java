package cl.evaluacion2.pedido_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidoMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidoMicroServicioApplication.class, args);
	}

}
