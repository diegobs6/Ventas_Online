package cl.evaluacion2.pedido_microServicio.Repository;

import cl.evaluacion2.pedido_microServicio.Model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido,Long> {
    List<Pedido> findAllByUsuarioId(Long usuarioId);

}
