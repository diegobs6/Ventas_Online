package cl.evaluacion2.pedido_microServicio.Controller;

import cl.evaluacion2.pedido_microServicio.Dto.PedidoRequest;
import cl.evaluacion2.pedido_microServicio.Dto.PedidoResponse;
import cl.evaluacion2.pedido_microServicio.Service.PedidoService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/pedidos")
@Slf4j
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @GetMapping("/usuario/{usuarioId}")
    public List<PedidoResponse> obtenerPedidosPorUsuario(@PathVariable Long usuarioId) {
        log.info("GET /v1/pedidos/usuario/{}", usuarioId);
        return pedidoService.obtenerPedidosPorUsuarioId(usuarioId);
    }

    @PostMapping
    public ResponseEntity<PedidoResponse> crearPedido(@Valid @RequestBody PedidoRequest pedidoRequest) {
        log.info("POST /v1/pedidos");
        PedidoResponse pedidoResponse = pedidoService.crearPedido(pedidoRequest);
        return new ResponseEntity<>(pedidoResponse, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<PedidoResponse>> obtenerPedidos() {
        log.info("GET /v1/pedidos");
        List<PedidoResponse> pedidos = pedidoService.obtenerTodosLosPedidos();
        return ResponseEntity.ok(pedidos);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PedidoResponse> actualizarPedido(
            @PathVariable Long id,
            @Valid @RequestBody PedidoRequest pedidoRequest) {
        log.info("PUT /v1/pedidos/{}", id);
        PedidoResponse pedidoResponse = pedidoService.actualizarPedido(id, pedidoRequest);
        return ResponseEntity.ok(pedidoResponse);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPedido(@PathVariable Long id) {
        log.info("DELETE /v1/pedidos/{}", id);
        pedidoService.eliminarPedido(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
