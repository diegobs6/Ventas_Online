package cl.evaluacion2.pedido_microServicio.Mapper;

import cl.evaluacion2.pedido_microServicio.Dto.PedidoRequest;
import cl.evaluacion2.pedido_microServicio.Dto.PedidoResponse;
import cl.evaluacion2.pedido_microServicio.Model.Pedido;
import org.springframework.stereotype.Component;

@Component
public class PedidoMapper {

    public Pedido fromRequest(PedidoRequest request) {
        return Pedido.builder()
                .usuarioId(request.getUsuarioId())
                .fechaPedido(request.getFechaPedido())
                .estado(request.getEstado())
                .total(request.getTotal())
                .direccionEnvio(request.getDireccionEnvio())
                .build();
    }

    public PedidoResponse toResponse(Pedido pedido) {
        return PedidoResponse.builder()
                .id(pedido.getId())
                .usuarioId(pedido.getUsuarioId())
                .fechaPedido(pedido.getFechaPedido())
                .estado(pedido.getEstado())
                .total(pedido.getTotal())
                .direccionEnvio(pedido.getDireccionEnvio())
                .build();
    }
}
