package cl.evaluacion2.pedido_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidoMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
