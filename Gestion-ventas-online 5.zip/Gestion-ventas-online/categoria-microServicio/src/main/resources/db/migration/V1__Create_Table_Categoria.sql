CREATE TABLE categoria (
  id BIGINT NOT NULL AUTO_INCREMENT,
  nombre_cat varchar(255) NOT NULL,
  descripcion varchar(255),
  estado boolean NOT NULL,
  fecha_creacion DATETIME NOT NULL, 
  
  CONSTRAINT PK_categoria PRIMARY KEY (id),
  CONSTRAINT UQ_categoria_nombre UNIQUE (nombre_cat)
);