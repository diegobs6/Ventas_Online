package cl.evaluacion2.categoria_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoriaMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoriaMicroServicioApplication.class, args);
	}

}
