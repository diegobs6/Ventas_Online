package cl.evaluacion2.categoria_microServicio.mapper;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import cl.evaluacion2.categoria_microServicio.dto.CategoriaRequest;
import cl.evaluacion2.categoria_microServicio.dto.CategoriaResponse;
import cl.evaluacion2.categoria_microServicio.model.Categoria;

@Component
public class CategoriaMapper {

    
    // convierte de DTO a entidad 
     
    public Categoria toEntity(CategoriaRequest dto) {
        if (dto == null) return null;

        Categoria entity = new Categoria();
        entity.setNombre(dto.getNombre());
        entity.setDescripcion(dto.getDescripcion());
    
        entity.setEstado(true);
        // la fecha se genera cuando se crea la entidad
        entity.setFechaCreacion(LocalDateTime.now());

        return entity;
    }

    
    // convierte de entidad a Dto de salida para mostrar al cliente
     
    public CategoriaResponse toResponse(Categoria entity) {
        if (entity == null) return null;

        CategoriaResponse response = new CategoriaResponse();
        response.setCategoriaId(entity.getCategoriaId());
        response.setNombre(entity.getNombre());
        response.setDescripcion(entity.getDescripcion());
        response.setEstado(entity.getEstado());
        response.setFechaCreacion(entity.getFechaCreacion());

        return response;
    }

   
    //convierte una lista de entidades a una lista de dto 
   
    public List<CategoriaResponse> toResponseList(List<Categoria> entities) {
        return entities.stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }
}
