package cl.evaluacion2.categoria_microServicio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.evaluacion2.categoria_microServicio.dto.CategoriaRequest;
import cl.evaluacion2.categoria_microServicio.dto.CategoriaResponse;
import cl.evaluacion2.categoria_microServicio.mapper.CategoriaMapper;
import cl.evaluacion2.categoria_microServicio.model.Categoria;
import cl.evaluacion2.categoria_microServicio.repository.CategoriaRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CategoriaService {

    @Autowired
    private CategoriaRepository catRepo;

    @Autowired
    private CategoriaMapper catMapper;

    // obtener lista de todas las categorías
    public List<CategoriaResponse> findAll() {
        List<Categoria> listaCategorias = catRepo.findAll();
        log.info("Categorias recuperadas. Total: {}", listaCategorias.size());
        return catMapper.toResponseList(listaCategorias);
    }

    // guardar una nueva categoría
    public CategoriaResponse save(CategoriaRequest request) {
        Categoria categoria = catMapper.toEntity(request);
        Categoria guardada = catRepo.save(categoria);

        log.info("Nueva categoria guardada exitosamente con ID: {}", guardada.getCategoriaId());
        return catMapper.toResponse(guardada);
    }

    // actualizar nombre y descripción
    public CategoriaResponse update(Long id, CategoriaRequest request) {
        Categoria existente = catRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + id));

        existente.setNombre(request.getNombre());
        existente.setDescripcion(request.getDescripcion());

        log.info("Actualizando informacion de la categoria ID: {}", id);
        return catMapper.toResponse(catRepo.save(existente));
    }

    // cambiar el estado activo/inactivo de la categoría
    public void cambiarEstado(Long id, Boolean nuevoEstado) {
        Categoria categoria = catRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + id));

        categoria.setEstado(nuevoEstado);
        catRepo.save(categoria);
        // Logueamos a qué estado cambió (true o false) para tener registro
        log.info("Categoria ID: {} cambio su estado a: {}", id, nuevoEstado);
    }

    // eliminar por ID
    public void delete(Long id) {
        if (!catRepo.existsById(id)) {
            throw new RuntimeException("No se puede eliminar: la categoría con ID " + id + " no existe");
        }
        catRepo.deleteById(id);
        log.info("Categoria ID: {} eliminada correctamente", id);
    }

    // obtener una categoría por ID
    public CategoriaResponse findById(Long id) {
        Categoria categoria = catRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada con el ID: " + id));

        log.info("Categoria ID: {} encontrada con exito", id);
        return catMapper.toResponse(categoria);
    }
}