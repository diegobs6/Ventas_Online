package cl.evaluacion2.categoria_microServicio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.evaluacion2.categoria_microServicio.dto.CategoriaRequest;
import cl.evaluacion2.categoria_microServicio.dto.CategoriaResponse;
import cl.evaluacion2.categoria_microServicio.service.CategoriaService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/categorias")
public class CategoriaController {

    @Autowired
    private CategoriaService catService;

    // obtener todas las categorías
    @GetMapping
    public ResponseEntity<List<CategoriaResponse>> listar() {
        log.info("Listando todas las categorias");
        return ResponseEntity.ok(catService.findAll());
    }

    // buscar por id
    @GetMapping("/{id}")
    public ResponseEntity<CategoriaResponse> buscarPorId(@PathVariable Long id) {
        log.info("Buscando categoria con ID: {}", id);
        return ResponseEntity.ok(catService.findById(id));
    }

    // crear
    @PostMapping
    public ResponseEntity<CategoriaResponse> crear(@Valid @RequestBody CategoriaRequest request) {
        log.info("Creando nueva categoria con nombre: '{}'", request.getNombre());
        return new ResponseEntity<>(catService.save(request), HttpStatus.CREATED);
    }

    // actualizar
    @PutMapping("/{id}")
    public ResponseEntity<CategoriaResponse> actualizar(@PathVariable Long id,
            @Valid @RequestBody CategoriaRequest request) {
        log.info("Actualizando categoria ID: {} con nuevos datos", id);
        return ResponseEntity.ok(catService.update(id, request));
    }

    // eliminar
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("Eliminando categoria ID: {}", id);
        catService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // cambio de estado
    @PatchMapping("/{id}/estado")
    public ResponseEntity<Void> cambiarEstado(@PathVariable Long id, @RequestParam Boolean nuevoEstado) {
        log.info("Cambiando estado de la categoria ID: {} a -> {}", id, nuevoEstado);
        catService.cambiarEstado(id, nuevoEstado);
        return ResponseEntity.ok().build();
    }
}