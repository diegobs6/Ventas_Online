package cl.evaluacion2.categoria_microServicio.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="categoria")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Categoria {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long categoriaId;

    @Column(name="nombre_cat",unique = true,nullable = false,length = 40)
    private String nombre;

    @Column(name = "descripcion",nullable = true)
    private String descripcion;

    @Column(name = "estado",nullable = false)
    private Boolean estado;

    @Column(name="fecha_creacion",nullable = false)
    private LocalDateTime fechaCreacion;

}
