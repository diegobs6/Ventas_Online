package cl.evaluacion2.categoria_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoriaMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
