package cl.evaluacion2.inventario_microServicio.Client;

import cl.evaluacion2.inventario_microServicio.Dto.ProductoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Component
@Slf4j
public class ProductoClient {

    private final WebClient webClient;

    public ProductoClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public ProductoResponse obtenerProductoPorId(Long productoId) {
        log.info("Consultando producto ID: {} en ms-productos", productoId);
        try {
            return webClient.get()
                    .uri("/api/productos/{id}", productoId)
                    .retrieve()
                    .bodyToMono(ProductoResponse.class)
                    .block();
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Producto ID {} no encontrado en ms-productos", productoId);
            throw new RuntimeException("Producto no encontrado: " + productoId);
        } catch (Exception e) {
            log.error("Error al conectar con ms-productos: {}", e.getMessage());
            throw new RuntimeException("No se pudo conectar con el servicio de productos.");
        }
    }
}