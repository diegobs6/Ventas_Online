package cl.evaluacion2.inventario_microServicio.Controller;

import cl.evaluacion2.inventario_microServicio.Dto.InventarioRequest;
import cl.evaluacion2.inventario_microServicio.Dto.InventarioResponse;
import cl.evaluacion2.inventario_microServicio.Service.InventarioService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/inventario")
@Slf4j
public class InventarioController {

    @Autowired
    private InventarioService inventarioService;

    @GetMapping("/producto/{productoid}")
    public List<InventarioResponse> obtenerInventarioPorProductoId(@PathVariable Long productoid) {
        log.info("GET /v1/inventarios/producto/{}", productoid);
        return inventarioService.obtenerInventariosPorProductoId(productoid);
    }

    @PostMapping()
    public ResponseEntity<InventarioResponse> crearInventario(@Valid @RequestBody InventarioRequest inventarioRequest) {
        log.info("POST /v1/inventarios");
        InventarioResponse inventarioResponse = inventarioService.crearInventario(inventarioRequest);
        return new ResponseEntity<>(inventarioResponse, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<InventarioResponse>> obtenerInventarios() {
        log.info("GET /v1/inventario");
        List<InventarioResponse> inventarios = inventarioService.obtenerTodosLosInventario();
        return ResponseEntity.ok(inventarios);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InventarioResponse> actualizarInventario(
            @PathVariable Long id,
            @Valid @RequestBody InventarioRequest inventarioRequest) {
        log.info("PUT /v1/inventario/{}", id);
        InventarioResponse inventarioResponse = inventarioService.actualizarInventario(id, inventarioRequest);
        return ResponseEntity.ok(inventarioResponse);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarInventario(@PathVariable Long id) {
        log.info("Eliminando inventario con el ID: {}", id);
        inventarioService.eliminarInventario(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
