package cl.evaluacion2.inventario_microServicio.Service;

import cl.evaluacion2.inventario_microServicio.Client.CategoriaClient;
import cl.evaluacion2.inventario_microServicio.Client.ProductoClient;
import cl.evaluacion2.inventario_microServicio.Dto.InventarioRequest;
import cl.evaluacion2.inventario_microServicio.Dto.InventarioResponse;
import cl.evaluacion2.inventario_microServicio.Dto.ProductoResponse;
import cl.evaluacion2.inventario_microServicio.Mapper.InventarioMapper;
import cl.evaluacion2.inventario_microServicio.Model.Inventario;
import cl.evaluacion2.inventario_microServicio.Repository.InventarioRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
public class InventarioService {

    @Autowired
    private InventarioRepository inventarioRepository;
    @Autowired
    private InventarioMapper inventarioMapper;
    @Autowired
    private ProductoClient productoClient;
    @Autowired
    private CategoriaClient categoriaClient; // ← nuevo

    // Crear inventario — ahora valida producto Y su categoría
    public InventarioResponse crearInventario(InventarioRequest inventarioRequest) {
        log.info("Creando inventario para el producto ID: {}", inventarioRequest.getProductoId());

        // Validar que el producto existe en ms-productos
        ProductoResponse producto = productoClient.obtenerProductoPorId(inventarioRequest.getProductoId());
        log.debug("Producto ID {} validado en ms-productos", inventarioRequest.getProductoId());

        // Validar que la categoria del producto existe en ms-categorias
        categoriaClient.obtenerCategoriaPorId(producto.getCategoriaId());
        log.debug("Categoria ID {} validada en ms-categorias", producto.getCategoriaId());

        Inventario inventario = inventarioMapper.fromRequest(inventarioRequest);
        Inventario savedInventario = inventarioRepository.save(inventario);
        log.info("Inventario creado con ID: {}", savedInventario.getId());

        return inventarioMapper.toResponse(savedInventario);
    }

    // Listar todos los inventarios
    public List<InventarioResponse> obtenerTodosLosInventario() {
        log.info("Obteniendo todos los inventarios");
        return inventarioRepository.findAll()
                .stream()
                .map(inventario -> inventarioMapper.toResponse(inventario))
                .collect(Collectors.toList());
    }

    // Buscar por producto ID
    public List<InventarioResponse> obtenerInventariosPorProductoId(Long productoId) {
        log.info("Obteniendo inventario para el producto ID: {}", productoId);
        List<Inventario> inventarios = inventarioRepository.findAllByProductoId(productoId);
        return inventarios.stream()
                .map(inventarioMapper::toResponse)
                .toList();
    }

    // Actualizar inventario — también valida categoria
    public InventarioResponse actualizarInventario(Long id, InventarioRequest inventarioRequest) {
        log.info("Actualizando inventario con ID: {}", id);

        Inventario inventario = inventarioRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("No se encontró inventario con ID: {}", id);
                    return new NoSuchElementException("No existe inventario con ID: " + id);
                });

        // Validar que el producto existe en ms-productos
        ProductoResponse producto = productoClient.obtenerProductoPorId(inventarioRequest.getProductoId());
        log.debug("Producto ID {} validado en ms-productos", inventarioRequest.getProductoId());

        // Validar que la categoria del producto existe en ms-categorias
        categoriaClient.obtenerCategoriaPorId(producto.getCategoriaId());
        log.debug("Categoria ID {} validada en ms-categorias", producto.getCategoriaId());

        inventario.setProductoId(inventarioRequest.getProductoId());
        inventario.setStockActual(inventarioRequest.getStockActual());
        inventario.setStockMin(inventarioRequest.getStockMin());
        inventario.setUltimaActualizacion(inventarioRequest.getUltimaActualizacion());

        Inventario updatedInventario = inventarioRepository.save(inventario);
        log.info("Inventario actualizado exitosamente con ID: {}", updatedInventario.getId());

        return inventarioMapper.toResponse(updatedInventario);
    }

    // Eliminar inventario
    public void eliminarInventario(Long id) {
        log.info("Eliminando inventario con el ID: {}", id);
        inventarioRepository.deleteById(id);
    }
}