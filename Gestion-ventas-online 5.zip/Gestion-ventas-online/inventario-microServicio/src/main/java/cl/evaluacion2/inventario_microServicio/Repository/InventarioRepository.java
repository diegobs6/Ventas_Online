package cl.evaluacion2.inventario_microServicio.Repository;

import cl.evaluacion2.inventario_microServicio.Model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InventarioRepository extends JpaRepository<Inventario, Long> {
    Optional<Inventario> findByProductoId(Long productoId);

    List<Inventario> findAllByProductoId(Long productoId);
}
