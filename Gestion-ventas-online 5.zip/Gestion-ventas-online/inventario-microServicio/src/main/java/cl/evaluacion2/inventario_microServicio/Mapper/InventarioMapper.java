package cl.evaluacion2.inventario_microServicio.Mapper;

import cl.evaluacion2.inventario_microServicio.Dto.InventarioRequest;
import cl.evaluacion2.inventario_microServicio.Dto.InventarioResponse;
import cl.evaluacion2.inventario_microServicio.Model.Inventario;
import org.springframework.stereotype.Component;

@Component
public class InventarioMapper {

    public Inventario fromRequest(InventarioRequest request) {
        return Inventario.builder()
                .productoId(request.getProductoId())
                .stockActual(request.getStockActual())
                .stockMin(request.getStockMin())
                .ultimaActualizacion(request.getUltimaActualizacion())
                .build();
    }

    public InventarioResponse toResponse(Inventario inventario) {
        return InventarioResponse.builder()
                .id(inventario.getId())
                .productoId(inventario.getProductoId())
                .stockActual(inventario.getStockActual())
                .stockMin(inventario.getStockMin())
                .ultimaActualizacion(inventario.getUltimaActualizacion())
                .build();
    }
}
