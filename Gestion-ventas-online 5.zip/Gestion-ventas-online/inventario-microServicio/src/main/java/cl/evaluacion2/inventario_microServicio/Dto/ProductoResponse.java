package cl.evaluacion2.inventario_microServicio.Dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ProductoResponse {
    private Long id;
    private String nombre;
    private String descripcion;
    private double precio;
    private Long CategoriaId;
    public boolean activo;
    private LocalDate fechaCreacion;
}
