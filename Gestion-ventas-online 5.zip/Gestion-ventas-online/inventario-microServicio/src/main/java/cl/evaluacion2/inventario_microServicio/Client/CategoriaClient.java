package cl.evaluacion2.inventario_microServicio.Client;

import cl.evaluacion2.inventario_microServicio.Dto.CategoriaResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Component
@Slf4j
public class CategoriaClient {

    private final WebClient webClient;

    public CategoriaClient(WebClient.Builder webClientBuilder,
            @Value("${microservicio.categoria.url}") String categoriaUrl) {
        this.webClient = webClientBuilder.baseUrl(categoriaUrl).build();
    }

    public CategoriaResponse obtenerCategoriaPorId(Long categoriaId) {
        log.info("Consultando categoria ID: {} en ms-categorias", categoriaId);
        try {
            return webClient.get()
                    .uri("/api/categorias/{id}", categoriaId)
                    .retrieve()
                    .bodyToMono(CategoriaResponse.class)
                    .block();
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Categoria ID {} no encontrada en ms-categorias", categoriaId);
            throw new RuntimeException("Categoria no encontrada: " + categoriaId);
        } catch (Exception e) {
            log.error("Error al conectar con ms-categorias: {}", e.getMessage());
            throw new RuntimeException("No se pudo conectar con el servicio de categorias.");
        }
    }
}