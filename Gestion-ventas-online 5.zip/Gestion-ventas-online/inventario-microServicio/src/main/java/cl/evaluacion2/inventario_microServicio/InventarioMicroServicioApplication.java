package cl.evaluacion2.inventario_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioMicroServicioApplication.class, args);
	}

}
