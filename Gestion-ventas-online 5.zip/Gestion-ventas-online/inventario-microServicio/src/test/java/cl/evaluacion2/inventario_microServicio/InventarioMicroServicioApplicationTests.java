package cl.evaluacion2.inventario_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
