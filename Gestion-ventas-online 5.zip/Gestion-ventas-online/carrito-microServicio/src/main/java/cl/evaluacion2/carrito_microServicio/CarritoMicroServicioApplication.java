package cl.evaluacion2.carrito_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarritoMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarritoMicroServicioApplication.class, args);
	}

}
