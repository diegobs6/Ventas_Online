package cl.evaluacion2.carrito_microServicio.model;

    public enum EstadoCarrito{
        ACTIVO,
        COMPRADO,
        ABANDONADO
    }

