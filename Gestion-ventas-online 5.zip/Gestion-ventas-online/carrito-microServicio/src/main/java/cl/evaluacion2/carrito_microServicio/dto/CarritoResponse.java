package cl.evaluacion2.carrito_microServicio.dto;
import java.time.LocalDateTime;
import java.util.List;

import cl.evaluacion2.carrito_microServicio.model.EstadoCarrito;
import lombok.Data;

@Data
public class CarritoResponse {
    private Long carritoId;
    private Long idUsuario;
    private LocalDateTime fechaCreacion;
    private EstadoCarrito estado;
    private List<ItemResponse> items;
    private Double total;
}
