package cl.evaluacion2.carrito_microServicio.exception;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}
