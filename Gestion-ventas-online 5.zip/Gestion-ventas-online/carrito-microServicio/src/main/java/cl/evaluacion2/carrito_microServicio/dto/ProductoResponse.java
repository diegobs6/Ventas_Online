package cl.evaluacion2.carrito_microServicio.dto;

import lombok.Data;

@Data
public class ProductoResponse {
    private Long id;
    private String nombre;
    private Double precio;
    private Long categoriaId;
    private Boolean activo;
}
