package cl.evaluacion2.carrito_microServicio.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.evaluacion2.carrito_microServicio.model.Carrito;
import cl.evaluacion2.carrito_microServicio.model.ItemCarrito;

@Repository
public interface ItemCarritoRepository extends JpaRepository<ItemCarrito, Long> {
    
    //  buscar ítems por el carrito padre
    List<ItemCarrito> findByCarrito(Carrito carrito);
    
    List<ItemCarrito> findByProductoId(Long productoId);   
}