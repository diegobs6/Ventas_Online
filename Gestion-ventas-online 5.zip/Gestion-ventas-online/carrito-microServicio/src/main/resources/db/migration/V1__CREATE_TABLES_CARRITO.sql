CREATE TABLE carrito (
    id_carrito BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_usuario BIGINT NOT NULL,
    fecha_creacion DATETIME NOT NULL,
    estado VARCHAR(20) NOT NULL
);


CREATE TABLE item_carrito (
    id_item BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_producto BIGINT NOT NULL,
    cantidad INT NOT NULL,
    precio_uni DOUBLE NOT NULL,
    id_carrito BIGINT NOT NULL,
    
    CONSTRAINT fk_carrito_item FOREIGN KEY (id_carrito) 
        REFERENCES carrito(id_carrito) 
        ON DELETE CASCADE
);