package cl.evaluacion2.carrito_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarritoMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
