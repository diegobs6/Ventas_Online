package cl.evaluacion2.reporte_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReporteMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
