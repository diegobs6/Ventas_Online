CREATE TABLE reporte_venta (
    id_reporte_venta BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha_generacion DATETIME NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    contenido TEXT,
    tipo_reporte VARCHAR(50) NOT NULL
);

CREATE TABLE detalle_reporte (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    reporte_id BIGINT NOT NULL,
    clave VARCHAR(100) NOT NULL,
    valor DOUBLE NOT NULL,
    descripcion VARCHAR(255),
    CONSTRAINT fk_reporte FOREIGN KEY (reporte_id) REFERENCES reporte_venta(id_reporte_venta)
);
