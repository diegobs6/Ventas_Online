package cl.evaluacion2.reporte_microServicio.mapper;

import org.springframework.stereotype.Component;

import cl.evaluacion2.reporte_microServicio.dto.request.DetalleRequest;
import cl.evaluacion2.reporte_microServicio.dto.response.DetalleResponse;
import cl.evaluacion2.reporte_microServicio.model.DetalleReporte;

@Component
public class DetalleMapper {

    public DetalleReporte toEntity(DetalleRequest dto) {
        if (dto == null) return null;

        DetalleReporte detalle = new DetalleReporte();
        detalle.setClave(dto.getClave());
        detalle.setValor(dto.getValor());
        detalle.setDescripcion(dto.getDescripcion());

        return detalle;
    }

    public DetalleResponse toResponse(DetalleReporte entidad) {
        if (entidad == null) return null;

        DetalleResponse dto = new DetalleResponse();
        dto.setId(entidad.getId());
        dto.setClave(entidad.getClave());
        dto.setValor(entidad.getValor());
        dto.setDescripcion(entidad.getDescripcion());

        return dto;
    }
}
