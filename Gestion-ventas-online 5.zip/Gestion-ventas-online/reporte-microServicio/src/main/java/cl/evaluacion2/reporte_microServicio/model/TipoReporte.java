package cl.evaluacion2.reporte_microServicio.model;

public enum TipoReporte {
    VENTAS_DIARIAS,
    MENSUALES,
    PRODUCTO_TOP,
    INGRESOS
}
