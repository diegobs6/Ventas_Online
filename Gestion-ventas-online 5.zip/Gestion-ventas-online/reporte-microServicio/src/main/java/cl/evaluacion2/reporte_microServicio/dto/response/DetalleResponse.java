package cl.evaluacion2.reporte_microServicio.dto.response;

import lombok.Data;

@Data
public class DetalleResponse {
    private Long id;
    private String clave;
    private Double valor;
    private String descripcion;
}
