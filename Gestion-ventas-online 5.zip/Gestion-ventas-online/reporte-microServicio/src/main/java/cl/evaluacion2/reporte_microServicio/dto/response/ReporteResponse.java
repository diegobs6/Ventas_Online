package cl.evaluacion2.reporte_microServicio.dto.response;

import java.time.LocalDateTime;

import lombok.Data;

import java.util.List;

import java.time.LocalDate;

@Data
public class ReporteResponse {
    private Long id;
    private LocalDateTime fechaGeneracion;
    private String tipoReporte;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String contenido;
    private List<DetalleResponse> detalles;
}
