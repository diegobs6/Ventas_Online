package cl.evaluacion2.reporte_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReporteMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReporteMicroServicioApplication.class, args);
	}

}
