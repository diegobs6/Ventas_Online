package cl.evaluacion2.reporte_microServicio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.evaluacion2.reporte_microServicio.dto.request.ReporteRequest;
import cl.evaluacion2.reporte_microServicio.dto.response.ReporteResponse;
import cl.evaluacion2.reporte_microServicio.service.ReporteService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/reportes")
public class ReporteController {

    @Autowired
    private ReporteService reporteService;

    // crear un nuevo reporte de ventas
    @PostMapping
    public ResponseEntity<ReporteResponse> crearReporte(@Valid @RequestBody ReporteRequest request) {
        ReporteResponse response = reporteService.crearReporte(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // obtener un reporte específico por ID
    @GetMapping("/{id}")
    public ResponseEntity<ReporteResponse> obtenerReporte(@PathVariable Long id) {
        ReporteResponse response = reporteService.obtenerReportePorId(id);
        return ResponseEntity.ok(response);
    }

    // listar todos los reportes
    @GetMapping
    public ResponseEntity<List<ReporteResponse>> listarReportes() {
        List<ReporteResponse> reportes = reporteService.listarReportes();
        return ResponseEntity.ok(reportes);
    }

    // eliminar un reporte por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarReporte(@PathVariable Long id) {
        reporteService.eliminarReporte(id);
        return ResponseEntity.noContent().build();
    }
}
