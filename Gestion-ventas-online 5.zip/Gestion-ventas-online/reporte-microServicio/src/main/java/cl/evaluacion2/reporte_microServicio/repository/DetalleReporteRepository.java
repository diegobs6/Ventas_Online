package cl.evaluacion2.reporte_microServicio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.evaluacion2.reporte_microServicio.model.DetalleReporte;

@Repository
public interface DetalleReporteRepository extends JpaRepository<DetalleReporte,Long> {
    
}
