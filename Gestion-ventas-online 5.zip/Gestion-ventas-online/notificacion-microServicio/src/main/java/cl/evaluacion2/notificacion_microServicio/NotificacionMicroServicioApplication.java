package cl.evaluacion2.notificacion_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificacionMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotificacionMicroServicioApplication.class, args);
	}

}
