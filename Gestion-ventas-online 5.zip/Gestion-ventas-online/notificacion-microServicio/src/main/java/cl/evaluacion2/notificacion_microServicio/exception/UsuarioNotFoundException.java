package cl.evaluacion2.notificacion_microServicio.exception;

public class UsuarioNotFoundException extends RuntimeException {

    public UsuarioNotFoundException(Long id) {
        super("Usuario no encontrado con ID: " + id);
    }

    public UsuarioNotFoundException(String mensaje) {
        super(mensaje);
    }
}
