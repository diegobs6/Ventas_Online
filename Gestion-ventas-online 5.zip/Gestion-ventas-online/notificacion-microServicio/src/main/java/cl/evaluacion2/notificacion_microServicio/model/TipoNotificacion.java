package cl.evaluacion2.notificacion_microServicio.model;

public enum TipoNotificacion {
    PEDIDO_CONFIRMADO,
    PAGO_APROBADO,
    ENVIO_DESPACHADO,
    ENVIO_ENTREGADO,
    PEDIDO_CANCELADO
}
