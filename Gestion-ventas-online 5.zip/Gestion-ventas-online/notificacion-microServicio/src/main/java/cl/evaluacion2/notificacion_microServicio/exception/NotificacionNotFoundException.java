package cl.evaluacion2.notificacion_microServicio.exception;

public class NotificacionNotFoundException extends RuntimeException {

    public NotificacionNotFoundException(Long id) {
        super("Notificación no encontrada con ID: " + id);
    }

    public NotificacionNotFoundException(String mensaje) {
        super(mensaje);
    }
}

