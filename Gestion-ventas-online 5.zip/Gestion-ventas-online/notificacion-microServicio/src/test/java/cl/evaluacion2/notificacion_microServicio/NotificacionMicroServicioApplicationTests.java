package cl.evaluacion2.notificacion_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacionMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
