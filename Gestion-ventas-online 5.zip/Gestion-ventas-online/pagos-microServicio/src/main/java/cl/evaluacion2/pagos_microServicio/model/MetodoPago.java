package cl.evaluacion2.pagos_microServicio.model;

public enum MetodoPago {
    TARJETA_CREDITO,
    TARJETA_DEBITO,
    TRANSFERENCIA,
    PAYPAL
}
