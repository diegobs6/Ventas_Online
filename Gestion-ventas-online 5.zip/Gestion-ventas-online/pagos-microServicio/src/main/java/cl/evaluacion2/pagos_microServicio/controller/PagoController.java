package cl.evaluacion2.pagos_microServicio.controller;

import cl.evaluacion2.pagos_microServicio.dto.PagoRequestDTO;
import cl.evaluacion2.pagos_microServicio.dto.PagoResponseDTO;
import cl.evaluacion2.pagos_microServicio.service.PagoService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pagos")
public class PagoController {

    private static final Logger log = LoggerFactory.getLogger(PagoController.class);

    private final PagoService pagoService;

    public PagoController(PagoService pagoService) {
        this.pagoService = pagoService;
    }

    // Obtiene todos los pagos registrados
    @GetMapping
    public ResponseEntity<List<PagoResponseDTO>> listarTodos() {
        log.info("GET /api/pagos - Listar todos los pagos");
        List<PagoResponseDTO> pagos = pagoService.listarTodos();
        return ResponseEntity.ok(pagos);
    }

    // Obtiene un pago por su id
    @GetMapping("/{id}")
    public ResponseEntity<PagoResponseDTO> obtenerPorId(@PathVariable Long id) {
        log.info("GET /api/pagos/{} - Obtener pago por ID", id);
        PagoResponseDTO pago = pagoService.obtenerPorId(id);
        return ResponseEntity.ok(pago);
    }

    // Obtiene todos los pagos asociados a un pedido
    @GetMapping("/pedido/{pedidoId}")
    public ResponseEntity<List<PagoResponseDTO>> listarPorPedido(@PathVariable Long pedidoId) {
        log.info("GET /api/pagos/pedido/{} - Listar pagos por pedido", pedidoId);
        List<PagoResponseDTO> pagos = pagoService.listarPorPedido(pedidoId);
        return ResponseEntity.ok(pagos);
    }

    // Lista pagos filtrados por estado
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<PagoResponseDTO>> listarPorEstado(@PathVariable String estado) {
        log.info("GET /api/pagos/estado/{} - Listar pagos por estado", estado);
        List<PagoResponseDTO> pagos = pagoService.listarPorEstado(estado);
        return ResponseEntity.ok(pagos);
    }

    // Procesa un nuevo pago
    @PostMapping
    public ResponseEntity<PagoResponseDTO> procesarPago(@Valid @RequestBody PagoRequestDTO dto) {
        log.info("POST /api/pagos - Procesar nuevo pago");
        PagoResponseDTO creado = pagoService.procesarPago(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    // Aprueba un pago en estado pendiente
    @PatchMapping("/{id}/aprobar")
    public ResponseEntity<PagoResponseDTO> aprobarPago(@PathVariable Long id) {
        log.info("PATCH /api/pagos/{}/aprobar - Aprobar pago", id);
        PagoResponseDTO aprobado = pagoService.aprobarPago(id);
        return ResponseEntity.ok(aprobado);
    }

    // Reembolsa un pago en estado aprobado
    @PatchMapping("/{id}/reembolsar")
    public ResponseEntity<PagoResponseDTO> reembolsarPago(@PathVariable Long id) {
        log.info("PATCH /api/pagos/{}/reembolsar - Reembolsar pago", id);
        PagoResponseDTO reembolsado = pagoService.reembolsarPago(id);
        return ResponseEntity.ok(reembolsado);
    }
}
