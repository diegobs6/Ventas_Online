package cl.evaluacion2.pagos_microServicio.exceptions;

public class PedidoNotFoundException extends RuntimeException {

    public PedidoNotFoundException(Long id) {
        super("Pedido no encontrado con ID: " + id);
    }

    public PedidoNotFoundException(String mensaje) {
        super(mensaje);
    }
}
