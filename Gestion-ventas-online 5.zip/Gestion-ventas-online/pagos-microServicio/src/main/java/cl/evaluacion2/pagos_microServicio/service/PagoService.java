package cl.evaluacion2.pagos_microServicio.service;

import cl.evaluacion2.pagos_microServicio.dto.PagoRequestDTO;
import cl.evaluacion2.pagos_microServicio.dto.PagoResponseDTO;
import cl.evaluacion2.pagos_microServicio.exceptions.*;
import cl.evaluacion2.pagos_microServicio.model.EstadoPago;
import cl.evaluacion2.pagos_microServicio.model.MetodoPago;
import cl.evaluacion2.pagos_microServicio.model.Pago;
import cl.evaluacion2.pagos_microServicio.repository.PagoRepository;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PagoService {

    private final PagoRepository pagoRepository;
    private final WebClient webClient;

    @Value("${microservicios.pedidos.url}")
    private String pedidosUrl;

    public PagoService(PagoRepository pagoRepository, WebClient.Builder webClientBuilder) {
        this.pagoRepository = pagoRepository;
        this.webClient = webClientBuilder.build();
    }

    // Obtener pagos registrados

    @Transactional(readOnly = true)
    public List<PagoResponseDTO> listarTodos() {
        log.info("Listando todos los pagos");
        List<Pago> pagos = pagoRepository.findAll();
        log.debug("Se encontraron {} pagos en total", pagos.size());
        return pagos.stream()
                .map(this::convertirAResponseDTO)
                .collect(Collectors.toList());
    }

    // Pago por id

    @Transactional(readOnly = true)
    public PagoResponseDTO obtenerPorId(Long id) {
        log.info("Buscando pago con ID: {}", id);
        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("No se encontró pago con ID: {}", id);
                    return new PagoNotFoundException(id);
                });
        log.debug("Pago encontrado: ID {}, estado {}", pago.getId(), pago.getEstado());
        return convertirAResponseDTO(pago);
    }

    // Obtiene todos los pagos de un pedido.

    @Transactional(readOnly = true)
    public List<PagoResponseDTO> listarPorPedido(Long pedidoId) {
        log.info("Listando pagos del pedido ID: {}", pedidoId);
        List<Pago> pagos = pagoRepository.findByPedidoId(pedidoId);
        log.debug("Se encontraron {} pagos para el pedido {}", pagos.size(), pedidoId);
        return pagos.stream()
                .map(this::convertirAResponseDTO)
                .collect(Collectors.toList());
    }

    // Lista pagos filtrados por estado.

    @Transactional(readOnly = true)
    public List<PagoResponseDTO> listarPorEstado(String estado) {
        log.info("Listando pagos con estado: {}", estado);
        EstadoPago estadoEnum = validarEstadoPago(estado);
        List<Pago> pagos = pagoRepository.findByEstado(estadoEnum);
        log.debug("Se encontraron {} pagos con estado {}", pagos.size(), estado);
        return pagos.stream()
                .map(this::convertirAResponseDTO)
                .collect(Collectors.toList());
    }

    // Procesa un nuevo pago.

    @Transactional
    public PagoResponseDTO procesarPago(PagoRequestDTO dto) {
        log.info("Procesando pago para pedido ID: {}", dto.getPedidoId());

        // Regla: validar que el pedido existe en ms-pedidos
        validarPedidoExiste(dto.getPedidoId());

        // Regla: un pedido no puede ser pagado dos veces
        if (pagoRepository.existsByPedidoIdAndEstado(dto.getPedidoId(), EstadoPago.APROBADO)) {
            log.warn("Intento de pago duplicado para pedido ID: {}", dto.getPedidoId());
            throw new PagoDuplicadoException(dto.getPedidoId());
        }

        // Validar el método de pago
        MetodoPago metodoPagoEnum = validarMetodoPago(dto.getMetodoPago());

        // Construir el pago
        Pago pago = Pago.builder()
                .pedidoId(dto.getPedidoId())
                .monto(dto.getMonto())
                .metodoPago(metodoPagoEnum)
                .estado(EstadoPago.PENDIENTE)
                .fechaPago(LocalDateTime.now())
                .referencia(UUID.randomUUID().toString().toUpperCase().replace("-", "").substring(0, 12))
                .build();

        Pago guardado = pagoRepository.save(pago);
        log.info("Pago creado exitosamente con ID: {} y referencia: {}", guardado.getId(), guardado.getReferencia());
        return convertirAResponseDTO(guardado);
    }

    // Aprueba un pago existente.

    @Transactional
    public PagoResponseDTO aprobarPago(Long id) {
        log.info("Aprobando pago con ID: {}", id);

        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("No se puede aprobar: pago con ID {} no encontrado", id);
                    return new PagoNotFoundException(id);
                });

        // Regla: solo se puede aprobar si está PENDIENTE
        if (pago.getEstado() != EstadoPago.PENDIENTE) {
            log.warn("No se puede aprobar pago ID {}: estado actual es {}", id, pago.getEstado());
            throw new IllegalStateException(
                    "Solo se puede aprobar un pago en estado PENDIENTE. Estado actual: " + pago.getEstado());
        }

        pago.setEstado(EstadoPago.APROBADO);
        Pago aprobado = pagoRepository.save(pago);
        log.info("Pago aprobado exitosamente: ID {}", aprobado.getId());
        return convertirAResponseDTO(aprobado);
    }

    // Rechaza un pago existente.

    @Transactional
    public PagoResponseDTO rechazarPago(Long id) {
        log.info("Rechazando pago con ID: {}", id);

        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("No se puede rechazar: pago con ID {} no encontrado", id);
                    return new PagoNotFoundException(id);
                });

        // Regla: solo se puede rechazar si está PENDIENTE
        if (pago.getEstado() != EstadoPago.PENDIENTE) {
            log.warn("No se puede rechazar pago ID {}: estado actual es {}", id, pago.getEstado());
            throw new IllegalStateException(
                    "Solo se puede rechazar un pago en estado PENDIENTE. Estado actual: " + pago.getEstado());
        }

        pago.setEstado(EstadoPago.RECHAZADO);
        Pago rechazado = pagoRepository.save(pago);
        log.info("Pago rechazado: ID {}", rechazado.getId());
        return convertirAResponseDTO(rechazado);
    }

    // Reembolsa un pago existente.

    @Transactional
    public PagoResponseDTO reembolsarPago(Long id) {
        log.info("Reembolsando pago con ID: {}", id);

        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("No se puede reembolsar: pago con ID {} no encontrado", id);
                    return new PagoNotFoundException(id);
                });

        // Regla: solo se puede reembolsar si está APROBADO
        if (pago.getEstado() != EstadoPago.APROBADO) {
            log.warn("No se puede reembolsar pago ID {}: estado actual es {}", id, pago.getEstado());
            throw new IllegalStateException(
                    "Solo se puede reembolsar un pago en estado APROBADO. Estado actual: " + pago.getEstado());
        }

        pago.setEstado(EstadoPago.REEMBOLSADO);
        Pago reembolsado = pagoRepository.save(pago);
        log.info("Pago reembolsado exitosamente: ID {}", reembolsado.getId());
        return convertirAResponseDTO(reembolsado);
    }

    // Valida que un pedido exista en ms-pedidos mediante WebClient.

    private void validarPedidoExiste(Long pedidoId) {
        log.info("Validando existencia de pedido ID: {} en ms-pedidos", pedidoId);
        try {
            webClient.get()
                    .uri(pedidosUrl + "/v1/pedidos/{id}", pedidoId)
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
            log.debug("Pedido ID {} validado correctamente", pedidoId);
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Pedido ID {} no encontrado en ms-pedidos", pedidoId);
            throw new PedidoNotFoundException(pedidoId);
        } catch (Exception e) {
            log.error("Error al conectar con ms-pedidos: {}", e.getMessage());
            throw new RuntimeException("No se pudo conectar con el servicio de pedidos. Intente más tarde.");
        }
    }

    // Valida que el string del método de pago sea un valor válido del enum

    private MetodoPago validarMetodoPago(String metodoPago) {
        try {
            return MetodoPago.valueOf(metodoPago.toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            log.warn("Método de pago no válido recibido: {}", metodoPago);
            throw new IllegalArgumentException(
                    "Método de pago no válido: '" + metodoPago + "'. Los valores permitidos son: "
                            + "TARJETA_CREDITO, TARJETA_DEBITO, TRANSFERENCIA, PAYPAL");
        }
    }

    // Valida que el string del estado sea un valor válido del enum EstadoPago.

    private EstadoPago validarEstadoPago(String estado) {
        try {
            return EstadoPago.valueOf(estado.toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            log.warn("Estado de pago no válido recibido: {}", estado);
            throw new IllegalArgumentException(
                    "Estado no válido: '" + estado + "'. Los valores permitidos son: "
                            + "PENDIENTE, APROBADO, RECHAZADO, REEMBOLSADO");
        }
    }

    // Convierte una entidad Pago a su DTO de respuesta.

    private PagoResponseDTO convertirAResponseDTO(Pago pago) {
        return PagoResponseDTO.builder()
                .id(pago.getId())
                .pedidoId(pago.getPedidoId())
                .monto(pago.getMonto())
                .metodoPago(pago.getMetodoPago().name())
                .estado(pago.getEstado().name())
                .fechaPago(pago.getFechaPago())
                .referencia(pago.getReferencia())
                .build();
    }
}
