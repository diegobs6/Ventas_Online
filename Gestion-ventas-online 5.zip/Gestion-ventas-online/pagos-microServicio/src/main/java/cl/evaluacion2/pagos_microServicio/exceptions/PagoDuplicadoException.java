package cl.evaluacion2.pagos_microServicio.exceptions;

public class PagoDuplicadoException extends RuntimeException {

    public PagoDuplicadoException(Long pedidoId) {
        super("El pedido con ID " + pedidoId + " ya cuenta con un pago aprobado");
    }
}
