package cl.evaluacion2.pagos_microServicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagosMicroServicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagosMicroServicioApplication.class, args);
	}

}
