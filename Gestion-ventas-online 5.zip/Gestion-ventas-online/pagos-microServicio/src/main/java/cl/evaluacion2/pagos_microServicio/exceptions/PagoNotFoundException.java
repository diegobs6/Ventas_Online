package cl.evaluacion2.pagos_microServicio.exceptions;

public class PagoNotFoundException extends RuntimeException {

    public PagoNotFoundException(Long id) {
        super("Pago no encontrado con ID: " + id);
    }

    public PagoNotFoundException(String mensaje) {
        super(mensaje);
    }
}
