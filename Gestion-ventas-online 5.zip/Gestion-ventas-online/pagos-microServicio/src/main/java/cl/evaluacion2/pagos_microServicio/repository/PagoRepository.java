package cl.evaluacion2.pagos_microServicio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import cl.evaluacion2.pagos_microServicio.model.EstadoPago;
import cl.evaluacion2.pagos_microServicio.model.MetodoPago;
import cl.evaluacion2.pagos_microServicio.model.Pago;

import java.util.List;
import java.util.Optional;

public interface PagoRepository extends JpaRepository<Pago, Long> {

    // Busca todos los pagos asociados a un pedido.

    List<Pago> findByPedidoId(Long pedidoId);

    // Busca el pago aprobado de un pedido.

    Optional<Pago> findByPedidoIdAndEstado(Long pedidoId, EstadoPago estado);

    // Lista todos los pagos por estado.

    List<Pago> findByEstado(EstadoPago estado);

    // Lista todos los pagos por método de pago.

    List<Pago> findByMetodoPago(MetodoPago metodoPago);

    // Verifica si ya existe un pago aprobado para un pedido.

    boolean existsByPedidoIdAndEstado(Long pedidoId, EstadoPago estado);
}
