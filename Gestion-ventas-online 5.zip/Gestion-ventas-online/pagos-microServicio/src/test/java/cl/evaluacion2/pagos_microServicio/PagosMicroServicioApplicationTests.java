package cl.evaluacion2.pagos_microServicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagosMicroServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
